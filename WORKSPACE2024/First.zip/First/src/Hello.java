// Isaac Smith 1-13-2024 Learning Java and Eclipse
public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello from CSC 151");
		System.out.println("Hello from CSC 151");
	}

}
