// Isaac Smith 1-13-2024 In Class Activity 1
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("You make me feel special");
		System.out.println("세상이 아무리 날 주저앉혀도");
		System.out.println("아프고 아픈 말들이 날 찔러도");
		System.out.println("네가 있어 난 다시 웃어");
		System.out.println("That's what you do");

	}

}
