// Isaac Smith 1-13-2024 In Class Activity 2
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("Okay, pigs stole our kids. That sucks.");
		System.out.println("Made all you guys look like idiots.");
		System.out.println("You know what we gotta do?");
		System.out.println("We start replacing those kids.");
		System.out.println("(CROUD GASPS)");
		System.out.println("Laides, Get Busy!");
		System.out.println("We're gonna be laying some eggs tonight!");
		System.out.println("No, no stop. No, no, no,no. No!");
		System.out.println("-Chuck and Red, The Angry Birds Movie (2016)");
	}

}
